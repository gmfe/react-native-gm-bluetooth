//
//  AppDelegate.h
//  搜索蓝牙
//
//  Created by 1 on 16/9/24.
//  Copyright © 2016年 cn.jft365.yunfengchao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ConnectViewController.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) ConnectViewController *mConnBLE;

@end

