//
//  main.m
//  搜索蓝牙
//
//  Created by 1 on 16/9/24.
//  Copyright © 2016年 cn.jft365.yunfengchao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
