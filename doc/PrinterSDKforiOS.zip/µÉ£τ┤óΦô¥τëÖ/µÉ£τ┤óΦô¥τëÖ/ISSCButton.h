//
//  ISSCButton.h
//  MFiAudioAPP
//
//  Created by Rick on 13/10/4.
//  Copyright (c) 2013年 ISSC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ISSCButton : UIButton

@end
